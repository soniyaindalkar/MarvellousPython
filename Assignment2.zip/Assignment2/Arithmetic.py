def Add(no1,no2):
        ans=int(no1)+int(no2)
        return ans

def Sub(no1,no2):
        ans=int(no1)-int(no2)
        return ans

def Mult(no1,no2):
        ans=int(no1)*int(no2)
        return ans

def Div(no1,no2):
        ans=int(no1)/int(no2)
        return ans

