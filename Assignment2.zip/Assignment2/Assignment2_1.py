from _ast import Mult

import Arithmetic;
from Arithmetic import *

#from Arithmetic import Add;

print("Enter first no")
no1=input()

print("Enter second no")
no2=input()


Addition=Arithmetic.Add(no1,no2)
print ("Addition of two numbers is" ,Addition)

Subtraction=Arithmetic.Sub(no1,no2)
print("Subtraction of two numbers is",Subtraction)

Division=Arithmetic.Div(no1,no2)
print("Division of two numbers is ",Division)

Multiplication=Mult(no1,no2)
print("Multiplication of two numbers is",Multiplication)