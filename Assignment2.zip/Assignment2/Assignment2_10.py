n=int(input("Enter a number"))
total=0

while(n>0):
    digit=n%10
    total=total+digit
    n=n//10   #n madhe quotient
    #print (n)
print("The total sum of digits is",total)



#123
#123/10=12   baki 3=digit
#

