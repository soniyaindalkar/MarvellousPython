def print_star():
    print("Enter no of stars")
    no=input()

    for i in range(int(no)):
        for j in range(int(no)):
                print("*",end=" ")
        print()

print_star()





