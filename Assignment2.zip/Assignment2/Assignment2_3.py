def fact(n):
    f = 1
    for i in range(1,n+1):
        #1*1*2*3
        f = f*i
    return f

print("Enter no")
no1=int(input())
#x=5
result=fact(no1)
print ("The factorial of given no is", result)
