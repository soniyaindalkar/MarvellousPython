def factors(number):
    result=0
    for i in range(1,number):
        if number%i==0:
            result=result+i
    return(result)


def main():

    number=int(input("Enter a number"))
    result=factors(number)
    print("Addition is ",result)

if __name__=="__main__":
    main()