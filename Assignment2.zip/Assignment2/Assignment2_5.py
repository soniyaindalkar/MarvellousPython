def check_prime(n):
    for i in range(2,n):
        if n % i==0:
            print("It is not prime no")
            break
    else:
            print("It is prime no")


print("Enter a number")
no=int(input())

check_prime(no)

