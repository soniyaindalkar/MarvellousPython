def print_triange(n):
    for i in range(int(no+1)):
        for j in range(int(no-i)):
            print("*",end=" ")
        print()

    #for i in range(int(no)):
    #    for j in range(int(no)):
    #            print("*",end=" ")
    #    print()

print("Enter no")
no=int(input())
print_triange(no)