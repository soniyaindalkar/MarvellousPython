def no_pattern(no):
    for i in range(no):
        for j in range(1,no+1):
                print(j,end=" ")
        print("")

print("Enter no")
n=int(input())

no_pattern(n)