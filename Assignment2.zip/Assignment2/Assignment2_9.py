n=int(input("Enter a number"))
cnt=0

while(n>0):
    digit=n%10
    #total=total+digit
    cnt=cnt+1
    n=n//10   #n madhe quotient
    #print (n)
print("The no of digits is",cnt)